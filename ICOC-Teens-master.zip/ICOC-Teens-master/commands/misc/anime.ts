module.exports = {
  name: "anime",
  execute(msg) {
    msg.reply(`It's //anime or /anime :)`);
    msg.delete();
  },
};
