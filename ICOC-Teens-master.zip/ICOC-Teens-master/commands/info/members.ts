module.exports = {
    name:"members",
    execute(msg) {

        //msg.member.guild.members.cache.forEach(member => msg.channel.send(member.user.username)); 

    },
};