module.exports = {
  name: "nou",
  permissions: 7,
  execute(msg) {
    msg.channel.send(
      `https://cdn.discordapp.com/emojis/596371124451934208.gif?v=1`
    );
  },
};
