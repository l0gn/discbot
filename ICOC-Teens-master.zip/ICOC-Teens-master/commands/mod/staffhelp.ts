module.exports = {
    name:"staffhelp",
    execute(msg) {

        msg.reply(`hehe`);

    },
};