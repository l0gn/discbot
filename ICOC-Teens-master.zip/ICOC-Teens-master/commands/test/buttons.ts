module.exports = {
  name: "buttons",
  permissions: 1,
  execute(msg) {},
};
