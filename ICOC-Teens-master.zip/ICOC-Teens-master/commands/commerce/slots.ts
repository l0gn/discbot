// module.exports = {
//     name:"slots",
//     execute(msg) {

//     },
// };
