# ICOC-Teens
Discord bot for ICOC Teens Discord Server

[![All Contributors](https://img.shields.io/badge/all_contributors-1-orange.svg?style=flat-square)](#contributors-)
[![chat](https://img.shields.io/discord/698590629344575500?style=flat-square)](https://discord.gg/33vsYgtHkx)

Dev - Chr1s (christopher#8888)
